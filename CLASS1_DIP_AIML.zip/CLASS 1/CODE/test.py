import os
import cv2

# Check if the file exists
image_path = r'D:\HAlDIA_HIT\CLASS 1\CODE\apple.jpg'

if not os.path.exists(image_path):
    raise FileNotFoundError(f"Image not found at path: {image_path}")
else:
    print("✅ Image file exists.")

# Attempt to load the image
rgb_image = cv2.imread(image_path)

if rgb_image is None:
    raise ValueError("❌ OpenCV failed to load the image. Check if the image is corrupted or in an unsupported format.")
else:
    print("✅ Image loaded successfully with OpenCV.")
