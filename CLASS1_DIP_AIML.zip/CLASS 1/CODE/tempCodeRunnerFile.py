_, binary_image = cv2.threshold(gray_image, 0, 255, cv2.THRESH_BINARY)
