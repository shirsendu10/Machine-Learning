import pyrealsense2 as rs
import cv2
import numpy as np
import matplotlib.pyplot as plt

# Initialize RealSense pipeline
pipeline = rs.pipeline()
config = rs.config()
config.enable_stream(rs.stream.color, 640, 480, rs.format.bgr8, 30)

# Start streaming
pipeline.start(config)

try:
    while True:
        # Wait for a coherent pair of frames
        frames = pipeline.wait_for_frames()
        color_frame = frames.get_color_frame()
        if not color_frame:
            continue

        # Convert to numpy array
        color_image = np.asanyarray(color_frame.get_data())

        # Perform Image Operations
        gray_image = cv2.cvtColor(color_image, cv2.COLOR_BGR2GRAY)
        binary_image = cv2.threshold(gray_image, 128, 255, cv2.THRESH_BINARY)[1]
        rgb_pixel_value = color_image[100, 100]  # Example pixel value at (100,100)

        # Display Image and Operations
        cv2.imshow('Original Image', color_image)
        cv2.imshow('Gray Image', gray_image)
        cv2.imshow('Binary Image', binary_image)

        # Show Histogram (Press 'h' to display histogram)
        if cv2.waitKey(1) & 0xFF == ord('h'):
            plt.figure("Histogram")
            plt.hist(gray_image.ravel(), 256, [0, 256])
            plt.title('Gray Image Histogram')
            plt.show()

        # Extract Meta Data (Example)
        metadata = {
            "Width": color_frame.get_width(),
            "Height": color_frame.get_height(),
            "Frame Number": color_frame.get_frame_number(),
            "Timestamp": color_frame.get_timestamp()
        }
        print("Meta Data:", metadata)

        # Exit on pressing 'q'
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

finally:
    pipeline.stop()
    cv2.destroyAllWindows()
